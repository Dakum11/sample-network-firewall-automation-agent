#!/bin/bash

# GitHub Agent Environment Setup
# Run this script to set up environment variables for the GitHub agent
# source setup-env.sh

export REPO_URL="https://github.com/sjcsjc001/network-firewall.git"
export PAT_TOKEN="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"
export GITHUB_API_URL="https://api.github.com/repos/sjcsjc001/network-firewall/pulls"
export VERBOSE="false"

echo "Environment variables set:"
echo "REPO_URL=$REPO_URL"
echo "PAT_TOKEN=${PAT_TOKEN:0:20}..."
echo "GITHUB_API_URL=$GITHUB_API_URL"
echo "VERBOSE=$VERBOSE"
